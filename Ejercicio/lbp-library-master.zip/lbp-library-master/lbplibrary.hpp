#pragma once

#include "package_lbp/LBP.h"
#include "package_lbp/olbp/OLBP.h"
#include "package_lbp/elbp/ELBP.h"
#include "package_lbp/varlbp/VARLBP.h"
#include "package_lbp/cslbp/CSLBP.h"
#include "package_lbp/csldp/CSLDP.h"
#include "package_lbp/oclbp/OCLBP.h"
#include "package_lbp/scslbp/SCSLBP.h"
#include "package_lbp/siltp/SILTP.h"
#include "package_lbp/xcslbp/XCSLBP.h"
#include "package_lbp/cssiltp/CSSILTP.h"
#include "package_lbp/bglbp/BGLBP.h"

#include "histogram.hpp"
